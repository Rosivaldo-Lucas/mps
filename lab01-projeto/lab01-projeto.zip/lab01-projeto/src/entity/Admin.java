package entity;

public class Admin extends Usuario {
    
}
